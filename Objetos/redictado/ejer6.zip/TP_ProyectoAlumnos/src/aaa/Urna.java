/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aaa;

/**
 *
 * @author Alumno
 */
public abstract class Urna {
    private int numeroDeUrna;
    private int votosEnBlanco=0;
    private Zona zona;

    public Urna(int numeroDeUrna, Zona zona) {
        this.numeroDeUrna = numeroDeUrna;
        this.zona = zona;
    }

    public int getNumeroDeUrna() {
        return numeroDeUrna;
    }

    public void setNumeroDeUrna(int numeroDeUrna) {
        this.numeroDeUrna = numeroDeUrna;
    }

    public Zona getZona() {
        return zona;
    }

    public void setZona(Zona zona) {
        this.zona = zona;
    }

    public int getVotosEnBlanco() {
        return votosEnBlanco;
    }

 
    public void votarEnBlanco (){
        this.votosEnBlanco++;
    }
    
    public abstract int calcularGanador();
    
    public int calcularTotalVotos (){
       return this.getVotosEnBlanco();
    }

    @Override
    public String toString() {
        return "Urna: " + numeroDeUrna + 
        "    "+ this.zona.toString()+ 
        "    Total de votos: "+this.calcularTotalVotos()+
        "    Ganador: "+this.calcularGanador();
    }
    
    
}
