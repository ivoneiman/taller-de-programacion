/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aaa;

/**
 *
 * @author Alumno
 */
public class UrnaElectoral extends Urna {
    private int listas;
    private int [] votos;

    public UrnaElectoral(int listas, int numeroDeUrna, Zona zona) {
        super(numeroDeUrna, zona);
        this.listas = listas;
        votos= new int [listas];
        for (int i=0;i<listas;i++)
            votos[i]=0;
    }

    public int getListas() {
        return listas;
    }

    public int[] getVotos() {
        return votos;
    }
    
     public boolean validarNumeroDeLista (int l){
         return (l<this.getListas());
     }
    
     public int devolverVotosPorLista(int l) {
        if (this.validarNumeroDeLista(l))
            return votos[l];
        else return -1;
    }
    
    
     
     public void votarPorLista (int l){
         if (this.validarNumeroDeLista(l))
             votos[l]++;
     }
     
    @Override
     public int calcularGanador (){
         int numGanador=-1;
         int canGanador=-1;
         for (int i=0;i<listas;i++){
             if (this.devolverVotosPorLista(i)>canGanador){
                 canGanador=this.devolverVotosPorLista(i);
                 numGanador=i;
             }
         }
         return numGanador;
     }
     
    @Override
       public int calcularTotalVotos (){
           int aux= super.calcularTotalVotos();
           for (int i=0;i<listas;i++){
               aux+= votos[i];
           }
           return aux;
    }
}
