/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aaa;

/**
 *
 * @author Alumno
 */
public class UrnaReferendum extends Urna {
    private int votosAFavor=0;
    private int votosEnContra=0;

    public UrnaReferendum(int numeroDeUrna, Zona zona) {
        super(numeroDeUrna, zona);
    }

    public int getVotosAFavor() {
        return votosAFavor;
    }

    public int getVotosEnContra() {
        return votosEnContra;
    }
    
    public void votarAFavor (){
        this.votosAFavor++;
    }
    public void votarEnContra (){
        this.votosEnContra++;
    }
    public int calcularGanador (){
        if (votosAFavor<votosEnContra)
            return -1;
        else if (votosAFavor>votosEnContra)
            return 1;
        else return 0;
    }
    @Override
    public int calcularTotalVotos (){
      return super.calcularTotalVotos()+this.getVotosAFavor()+this.getVotosEnContra();
    }
}
