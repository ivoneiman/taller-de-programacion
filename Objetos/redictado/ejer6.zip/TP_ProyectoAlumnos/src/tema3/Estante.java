/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema3;

import com.sun.xml.internal.txw2.output.IndentingXMLFilter;

/**
 *
 * @author Alumno
 */
public class Estante {
    private Libro[] estante=new Libro[20];
    private int dimL=0;
    public int cantidadLibros(){
        return dimL;
    }    
    public boolean estaLleno(){
        return (dimL==20);
             
    }
    public void agregarLibro(Libro l){
        if (dimL<19){
        estante[dimL]=l;
        dimL=dimL+1;
        }
    }
    public Libro devolverLibro(String nombre){
       int i=0;
       while((estante[i].getTitulo()!= nombre)&&(i<dimL))
           i=i+1;
       if (estante[i].getTitulo()==nombre)
           return estante[i];
       else
            System.out.println("no esta ese libro");
       return null;
    }
 }
    

