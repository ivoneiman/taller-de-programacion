/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema3;

/**
 *
 * @author Alumno
 */
import PaqueteLectura.GeneradorAleatorio;
public class Hotel {
    int df;
    Habitacion [] v ;
    public Hotel(int df){
        this.df = df;
        GeneradorAleatorio.iniciar();
        v= new Habitacion [df];
        int i;
        for(i = 0; i < df; i++){
            v[i] = new Habitacion(true, GeneradorAleatorio.generarDouble(2000) + 6000 );
        }
    }
    public void nuevoCliente(Cliente c, int i){
        v[i].nuevoCliente(c);
    }
    public void aumentarPrecio(dobuble c){
    
    }
}
