/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema3;

/**
 *
 * @author Alumno
 */
public class Prueba {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Estante estante=new Estante();
        estante.agregarLibro(new Libro("mujercitas","lore",new Autor("fran","un tipo piola","Las FLoreas"),"hola"));
        System.out.println(estante.cantidadLibros());
        System.out.println(estante.devolverLibro("mujercitas").toString());
        System.out.println(estante.estaLleno());
    }
}
