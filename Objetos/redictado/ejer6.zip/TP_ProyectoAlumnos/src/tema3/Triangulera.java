/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema3;

import PaqueteLectura.Lector;
public class Triangulera {

   
    public static void main(String[] args) {
        System.out.println("diga lado 1");
        double lado1=Lector.leerDouble();
        System.out.println("diga lado 2");
        double lado2=Lector.leerDouble();
        System.out.println("diga lado 3");
        double lado3=Lector.leerDouble();
        System.out.println("diga color relleno");
        String color1=Lector.leerString();
        System.out.println("diga color linea");
        String color2=Lector.leerString();
        
        
       Triangulo triangulo1= new Triangulo(lado1,lado2,lado3,color1,color2);
       System.out.println(triangulo1.calcularPerimetro());
        System.out.println(triangulo1.calcularArea());
    }
    
}
