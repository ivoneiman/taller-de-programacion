/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema3;

/**
 *
 * @author Alumno
 */
public class Triangulo {
    private double lado1,lado2,lado3;
    private String colorRelleno,colorLinea;
    public double calcularPerimetro(){
        return lado1+lado2+lado3;
    }

    public Triangulo(double lado1, double lado2, double lado3, String colorRelleno, String colorLinea) {
        this.lado1 = lado1;
        this.lado2 = lado2;
        this.lado3 = lado3;
        this.colorRelleno = colorRelleno;
        this.colorLinea = colorLinea;
    }
    public double calcularArea(){
        return Math.sqrt(((lado1+lado2+lado3)/2)*(((lado1+lado2+lado3)/2)-lado1)*(((lado1+lado2+lado3)/2)-lado2)*(((lado1+lado2+lado3)/2)-lado3));
    }
}
