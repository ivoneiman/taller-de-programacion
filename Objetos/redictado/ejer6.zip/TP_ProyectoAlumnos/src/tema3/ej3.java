/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema3;

/**
 *
 * @author Alumno
 */
import PaqueteLectura.Lector;
public class ej3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Estante n = new Estante(8);
        Libro l;
        l = new Libro("titulo" , "Editorial", "PrimerAutor", "0");
        n.nuevoLibro(l);
        n.nuevoLibro(l);
        n.nuevoLibro(l);
        System.out.println(n.cantLibros());
        System.out.println(n.estaLLeno());
        System.out.println(n.devolverLibro("titulo"));
    }
    
}
