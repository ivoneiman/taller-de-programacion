/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ukgug;

/**
 *
 * @author Alumno
 */
public abstract class Estacion {
    private String nombre;
    private double latitud;
    private double longitud;
    private double[][] sistema; 
    private int añoBase;
    private int añosConsecutivos;
    private int meses = 12;
    
    public Estacion(String nombre, double latitud, double longitud, int N, int A) {
        setNombre(nombre);
        setLatitud(latitud);
        setLongitud(longitud);
        añoBase = A;
        añosConsecutivos = N;
        sistema = new double[N][meses]; // N = años consecutivos ; 12 = meses
        for (int i = 0; i < N ; i++){
            for (int j = 0; j < meses; j++){
                sistema[i][j] = 999;
        }
        }
    }
    
    public String temperaturaMax(){
        String aux="";
        double max = -1;
        for (int i = 0; i < añosConsecutivos ; i++){
            for (int j = 0; j < 12; j++){
                if (sistema[i][j] > max){
                    max = sistema[i][j];
                    aux="Año "+i+" Mes "+j+" mayor temperatura: "+max;
                }
            }
        }
        return aux;
    }
    
    public void registrarTemperatura(int mes, int año,double temp){
        sistema[año][mes] = temp;
    }
    
    public double obtenerTemperatura(int mes, int año){
        return sistema[año][mes];
    }
    
    public String getNombre() {
        return nombre;
    }

    private void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getLatitud() {
        return latitud;
    }

    private void setLatitud(double latitud) {
        this.latitud = latitud;
    }

    public double getLongitud() {
        return longitud;
    }

    private void setLongitud(double longitud) {
        this.longitud = longitud;
    }

    public double[][] getSistema() {
        return sistema;
    }

    public void setSistema(double[][] sistema) {
        this.sistema = sistema;
    }

    public int getAñoBase() {
        return añoBase;
    }

    public void setAñoBase(int añoBase) {
        this.añoBase = añoBase;
    }

    public int getAñosConsecutivos() {
        return añosConsecutivos;
    }

    public void setAñosConsecutivos(int añosConsecutivos) {
        this.añosConsecutivos = añosConsecutivos;
    }

    public int getMeses() {
        return meses;
    }

    public void setMeses(int meses) {
        this.meses = meses;
    }

    
    
    
    
    
    public abstract double calcularPromedio(int n);
}
