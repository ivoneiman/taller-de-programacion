/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ukgug;

/**
 *
 * @author Alumno
 */
public class PromedioAños extends Estacion{

    public PromedioAños(String nombre, double latitud, double longitud, int N, int A) {
        super(nombre, latitud, longitud, N, A);
    }
    
   public double calcularPromedio(int año){
       double aux = 0;
       for (int i = 0; i < super.getMeses(); i++){
           aux += super.getSistema()[año][i];
       }
       aux = aux / super.getMeses();
       return aux;
   }
   
   public String toString(){
       String aux=super.getNombre()+" ( "+getLatitud()+getLongitud()+" )\n";
       for (int i = 0; i<super.getAñosConsecutivos(); i++){
           aux += "Año: "+(i+getAñoBase())+": "+calcularPromedio(i)+"°C \n";
       }
       return aux;
   }
   
   
}
