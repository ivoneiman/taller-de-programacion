/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ukgug;

/**
 *
 * @author Alumno
 */
public class PromedioMeses extends Estacion {

    public PromedioMeses(String nombre, double latitud, double longitud, int N, int A) {
        super(nombre, latitud, longitud, N, A);
    }
    
    
    
    public double calcularPromedio(int mes){
       double aux = 0;
       double max = -1;
       for(int i = 0; i< getAñosConsecutivos();i++){
           aux += getSistema()[i][mes];
       }
       aux = aux / getAñosConsecutivos();
       return aux;
    }
    
    public String toString(){
        String aux = super.getNombre()+" ( "+getLatitud()+getLongitud()+" )\n";
        for (int i = 0;i<getMeses(); i++){
            aux += "mes"+(i+1)+":"+calcularPromedio(i)+"°C \n";
        }
        return aux;
    }
}
