/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ukgug;

import PaqueteLectura.GeneradorAleatorio;
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        PromedioMeses reporteMes = new PromedioMeses("TYC sports", 10, 20, 4, 2020);
        
        PromedioAños reporteAños = new PromedioAños("ESPN", 220, 3320, 4, 2021);
        
        for (int i = 0; i < 4 ; i++){
            for (int j = 0; j < 12; j++){
                reporteMes.registrarTemperatura(j, i, GeneradorAleatorio.generarDouble(99));
                reporteAños.registrarTemperatura(j, i, GeneradorAleatorio.generarDouble(99));
            }
        }
        
        
        System.out.println(reporteAños.toString());
        
    }
    
}
